/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum12;

/**
 *
 * @author LENOVO
 */
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Kelas utama
public class SistemManajemenBuku {
    private static final String TEXT_FILE = "buku.txt";
    private static final String SERIAL_FILE = "buku.ser";

    private static List<Buku> daftarBuku = new ArrayList<>();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Simpan ke buku.txt");
            System.out.println("3. Simpan objek ke buku.ser");
            System.out.println("4. Tampilkan data dari buku.txt");
            System.out.println("5. Tampilkan dari buku.ser");
            System.out.println("6. Keluar");
            System.out.print("Pilihan: ");

            int pilihan = sc.nextInt();
            sc.nextLine(); 

            switch (pilihan) {
                case 1 -> tambahBuku(sc);
                case 2 -> simpanTeks();
                case 3 -> simpanSerial();
                case 4 -> tampilTeks();
                case 5 -> tampilSerial();
                case 6 -> {
                    System.out.println("Program selesai.");
                    return;
                }
                default -> System.out.println("Pilihan tidak valid.");
            }
        }
    }

    private static void tambahBuku(Scanner sc) {
        System.out.print("Judul: ");
        String judul = sc.nextLine();

        System.out.print("Pengarang: ");
        String pengarang = sc.nextLine();

        System.out.print("Tahun terbit: ");
        int tahun = sc.nextInt();

        daftarBuku.add(new Buku(judul, pengarang, tahun));
        System.out.println("Buku berhasil ditambahkan.");
    }

    private static void simpanTeks() {
        try (FileWriter fw = new FileWriter(TEXT_FILE)) {
            for (Buku b : daftarBuku) {
                fw.write(b.toString() + "\n");
            }
            System.out.println("Data berhasil disimpan ke buku.txt");
        } catch (IOException e) {
            System.out.println("Kesalahan saat menyimpan ke buku.txt");
            e.printStackTrace();
        }
    }

    private static void simpanSerial() {
        try (ObjectOutputStream oos =
                new ObjectOutputStream(new FileOutputStream(SERIAL_FILE))) {

            oos.writeObject(daftarBuku);
            System.out.println("Objek buku berhasil disimpan ke buku.ser");

        } catch (IOException e) {
            System.out.println("Kesalahan menyimpan file serial.");
            e.printStackTrace();
        }
    }

    private static void tampilTeks() {
        try (BufferedReader br = new BufferedReader(new FileReader(TEXT_FILE))) {
            String line;
            System.out.println("\nIsi buku.txt:");
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                Buku b = new Buku(data[0], data[1], Integer.parseInt(data[2]));
                b.tampilkan();
            }
        } catch (IOException e) {
            System.out.println("Tidak bisa membaca buku.txt");
            e.printStackTrace();
        }
    }

    private static void tampilSerial() {
        try (ObjectInputStream ois =
                new ObjectInputStream(new FileInputStream(SERIAL_FILE))) {

            List<Buku> list = (List<Buku>) ois.readObject();
            System.out.println("\nIsi buku.ser:");
            for (Buku b : list) {
                b.tampilkan();
            }

        } catch (Exception e) {
            System.out.println("Tidak bisa membaca buku.ser");
            e.printStackTrace();
        }
    }
}