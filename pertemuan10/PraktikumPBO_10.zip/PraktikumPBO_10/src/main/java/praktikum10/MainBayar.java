/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum10;

/**
 *
 * @author LENOVO
 */
public class MainBayar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pembayaran produkElektronik = new Elektronik();
        Pembayaran produkMakanan = new Makanan();

        double pajakElektronik = produkElektronik.hitungPajak(800000);
        double pajakMakanan = produkMakanan.hitungPajak(30000);

        System.out.println("Pajak produk elektronik: " + pajakElektronik);
        System.out.println("Pajak produk makanan: " + pajakMakanan);
    }
}