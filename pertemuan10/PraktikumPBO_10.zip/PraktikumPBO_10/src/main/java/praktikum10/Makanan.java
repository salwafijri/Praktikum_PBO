/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum10;

/**
 *
 * @author LENOVO
 */
// Kelas Makanan
public class Makanan implements Pembayaran {
    public double hitungPajak(double harga) {
        return harga * 0.05;
    }
}
