/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikumpbo_10;

/**
 *
 * @author LENOVO
 */
public class PraktikumPBO_10 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
