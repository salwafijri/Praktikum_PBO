/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum6;

/**
 *
 * @author LENOVO
 */
public class MainProduk {
    public static void main(String[] args) {
        KeranjangBelanja keranjang = new KeranjangBelanja(5);

        Produk buku1 = new Buku("Buku bacaan Java is fun!", 100000.0);
        Produk laptop = new Elektronik("Laptop Lenovo Thinkpad", 6000000.0);
        Produk kaos = new Pakaian("Kemeja Kotak-kotak", 150000.0);

        keranjang.tambahProduk(buku1);
        keranjang.tambahProduk(laptop);
        keranjang.tambahProduk(kaos);

        keranjang.tampilkanIsiKeranjang();
        System.out.println("\nTotal Harga Setelah Diskon: Rp" + keranjang.hitungTotal());
    }
}