/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum6;

/**
 *
 * @author LENOVO
 */
public class KeranjangBelanja {
    private Produk[] produkList;
    private int jumlahProduk;
 
    public KeranjangBelanja(int kapasitas) {
        produkList = new Produk[kapasitas];
        jumlahProduk = 0;
    }
    public void tambahProduk(Produk p) {
        if (jumlahProduk < produkList.length) {
            produkList[jumlahProduk] = p;
            jumlahProduk++;
        } else {
            System.out.println("Keranjang penuh, tidak bisa menambah produk lagi :(");
        }
    }
    public double hitungTotal() {
        double total = 0;
        for (int i = 0; i < jumlahProduk; i++) {
            total += produkList[i].getHargaSetelahDiskon();
        }
        return total;
    }
    public void tampilkanIsiKeranjang() {
        System.out.println("Isi Keranjang:");
        for (int i = 0; i < jumlahProduk; i++) {
            Produk p = produkList[i];
            System.out.println("- " + p.getNama() +
                               " , Harga: Rp" + p.getHarga() +
                               " , Setelah Diskon: Rp" + p.getHargaSetelahDiskon());
        }
    }
}