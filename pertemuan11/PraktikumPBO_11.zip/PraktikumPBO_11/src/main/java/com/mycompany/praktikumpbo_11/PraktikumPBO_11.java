/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikumpbo_11;

/**
 *
 * @author Acer
 */
public class PraktikumPBO_11 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
