/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum11;

/**
 *
 * @author Acer
 */
public class MainKlub {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Membuat objek Anggota
        Anggota a1 = new Anggota("Rayyan");
        Anggota a2 = new Anggota("Rafael");
        Anggota a3 = new Anggota("Raissa");
        Anggota a4 = new Anggota("Moana");
        Anggota a5 = new Anggota("Lintang");
        Anggota a6 = new Anggota("Guntur");

        // Membuat objek Klub
        Klub klubVoli = new Klub("Klub Bola Voli");

        // Menambahkan anggota ke klub
        klubVoli.tambahAnggota(a1);
        klubVoli.tambahAnggota(a2);
        klubVoli.tambahAnggota(a3);
        klubVoli.tambahAnggota(a4);
        klubVoli.tambahAnggota(a5);
        klubVoli.tambahAnggota(a6);

        // Menampilkan informasi klub dan anggotanya
        klubVoli.infoKlub();
        
    }
}