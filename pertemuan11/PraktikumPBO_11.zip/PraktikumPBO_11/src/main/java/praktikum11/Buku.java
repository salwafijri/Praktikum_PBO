/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum11;

/**
 *
 * @author Acer
 */
import java.util.List;
import java.util.ArrayList;

public class Buku {
    private String judul;
    private List<Pengarang> listPengarang;
    
    public Buku(String judul) {
    this.judul = judul;
    this.listPengarang = new ArrayList<>();
    }
    
    public void tambahPengarang(Pengarang p) {
    listPengarang.add(p);
    }
    
    public void infoBuku() {
    System.out.println("Judul Buku: " + judul);
        for (Pengarang p : listPengarang) {
            p.infoPengarang();
        }
    }
}