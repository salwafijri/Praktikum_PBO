/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum11;

/**
 *
 * @author Acer
 */
public class MainPerpus {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Membuat objek-objek Buku
        Buku buku1 = new Buku("Pandai Pemrograman");
        Buku buku2 = new Buku("Kamus Inggris Indonesia");
        Buku buku3 = new Buku("Jaringan Komputer");
        
        Pengarang p1 = new Pengarang("Sheila Wardana\n");
        Pengarang p2 = new Pengarang("Reihan Pratama\n");
        Pengarang p3 = new Pengarang("Muhammad Bilad");
        
        buku1.tambahPengarang(p1);
        buku2.tambahPengarang(p2);
        buku3.tambahPengarang(p3);

        // Membuat objek Perpustakaan
        Perpustakaan perpustakaan = new Perpustakaan();

        // Menambahkan buku ke perpustakaan
        perpustakaan.tambahBuku(buku1);
        perpustakaan.tambahBuku(buku2);
        perpustakaan.tambahBuku(buku3);

        // Menampilkan informasi perpustakaan
        System.out.println("info Perpustakaan");
        perpustakaan.infoPerpustakaan();
    }
}