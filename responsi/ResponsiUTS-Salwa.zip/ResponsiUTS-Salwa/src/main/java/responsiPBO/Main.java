/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsiPBO;

/**
 *
 * @author LENOVO
 */
public class Main {
    public static void main(String[] args) {
        // Objek Produk
        Produk laptop = new Elektronik("Laptop", 12000000, 2);
        laptop.tampilkanInfo();

        System.out.println();

        // Objek Pegawai
        Pegawai salwa = new PegawaiTetap("Salwa", 7000000, 1000000);
        salwa.tampilkanInfo();

        System.out.println();

        // Polimorfisme Produk (referensi induk ke objek turunan)
        Produk snack = new Makanan("Snack", 15000, "2023-12-22");
        snack.tampilkanInfo();

        System.out.println();

        // Polimorfisme Pegawai (referensi induk ke objek turunan)
        Pegawai fijri = new PegawaiKontrak("Fijri", 3500000, 12);
        fijri.tampilkanInfo();
    }
}